# Tests for CAPEX dashboard
